<?php
session_start();
include 'db.php';
if(!isset($_SESSION['user_id'])){ header('Location: login.php'); exit; }
include 'partials/header.php';
?>
<div class="container py-5">
    <h3>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?></h3>
    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card p-3 shadow">
                <h5>My Appointments</h5>
                <ul>
                <?php
                $uid = $_SESSION['user_id'];
                $res = mysqli_query($conn, "SELECT * FROM appointments WHERE user_id=$uid ORDER BY id DESC");
                while($r = mysqli_fetch_assoc($res)){
                    echo '<li>'.htmlspecialchars($r['doctor']).' - '.htmlspecialchars($r['date']).' '.htmlspecialchars($r['time']).'</li>';
                }
                ?>
                </ul>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3 shadow">
                <h5>Upload Records</h5>
                <p><a href="records.php" class="btn btn-sm btn-primary">Go to Records</a></p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3 shadow">
                <h5>Order Medicines</h5>
                <p><a href="order_medicine.php" class="btn btn-sm btn-primary">Order Now</a></p>
            </div>
        </div>
    </div>
</div>
<?php include 'partials/footer.php'; ?>
