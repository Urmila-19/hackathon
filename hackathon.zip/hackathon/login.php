<?php
session_start();
include 'db.php';
$msg = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = $_POST['password'];
    $res = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if($res && mysqli_num_rows($res) > 0){
        $user = mysqli_fetch_assoc($res);
        if(password_verify($pass, $user['password'])){
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            header('Location: dashboard.php'); exit;
        } else { $msg = 'Invalid credentials'; }
    } else { $msg = 'No user found'; }
}
include 'partials/header.php';
?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow p-4">
                <h3 class="text-center mb-3">Login</h3>
                <?php if($msg) echo '<div class="alert alert-danger">'.htmlspecialchars($msg).'</div>'; ?>
                <form method="POST">
                    <input type="email" name="email" class="form-control mb-3" placeholder="Email" required>
                    <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>
                    <button class="btn btn-primary w-100">Login</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include 'partials/footer.php'; ?>
