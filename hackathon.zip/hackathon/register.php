<?php
include 'db.php';
$msg = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $q = "INSERT INTO users (name,email,password,phone) VALUES ('$name','$email','$password','$phone')";
    if(mysqli_query($conn, $q)){
        header('Location: login.php'); exit;
    } else {
        $msg = 'Registration failed or email exists';
    }
}
include 'partials/header.php';
?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="card shadow p-4">
                <h3 class="text-center mb-3">Create Account</h3>
                <?php if($msg) echo '<div class="alert alert-danger">'.htmlspecialchars($msg).'</div>'; ?>
                <form method="POST">
                    <div class="row g-3">
                        <div class="col-md-6"><input type="text" name="name" class="form-control" placeholder="Full Name" required></div>
                        <div class="col-md-6"><input type="text" name="phone" class="form-control" placeholder="Phone" required></div>
                    </div>
                    <input type="email" name="email" class="form-control mt-3" placeholder="Email" required>
                    <input type="password" name="password" class="form-control mt-3" placeholder="Password" required>
                    <button class="btn btn-primary w-100 mt-3">Register</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include 'partials/footer.php'; ?>
