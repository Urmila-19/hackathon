<?php include 'partials/header.php'; ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card p-4 shadow">
                <h3 class="text-center mb-3">Contact Us</h3>
                <form method="POST">
                    <input type="text" name="name" class="form-control mb-3" placeholder="Name">
                    <input type="email" name="email" class="form-control mb-3" placeholder="Email">
                    <textarea name="message" class="form-control mb-3" rows="4" placeholder="Message"></textarea>
                    <button class="btn btn-primary w-100">Send</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include 'partials/footer.php'; ?>
