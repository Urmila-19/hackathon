<?php
include 'partials/header.php';
$msg = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    // simple demonstration - in real app store order in DB
    $msg = 'Medicine order placed successfully';
}
?>
<div class="container py-5">
    <div class="card p-4 shadow">
        <h3 class="mb-3">Order Medicines</h3>
        <?php if($msg) echo '<div class="alert alert-success">'.htmlspecialchars($msg).'</div>'; ?>
        <form method="POST">
            <input type="text" name="med" class="form-control mb-3" placeholder="Medicine Name" required>
            <input type="number" name="qty" class="form-control mb-3" placeholder="Quantity" required>
            <button class="btn btn-primary w-100">Place Order</button>
        </form>
    </div>
</div>
<?php include 'partials/footer.php'; ?>
