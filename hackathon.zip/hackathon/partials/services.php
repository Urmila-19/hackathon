<section class="py-5">
    <div class="container">
        <h2 class="text-center fw-bold mb-4">Our Services</h2>
        <div class="row g-4">
            <div class="col-md-3">
                <div class="card service-card shadow p-3 text-center">
                    <img src="assets/img/records.png" height="80" class="mx-auto" alt="Records" />
                    <h5 class="mt-3">Health Records</h5>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card service-card shadow p-3 text-center">
                    <img src="assets/img/doctor.png" height="80" class="mx-auto" alt="Doctor" />
                    <h5 class="mt-3">Appointments</h5>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card service-card shadow p-3 text-center">
                    <img src="assets/img/medicine.png" height="80" class="mx-auto" alt="Medicine" />
                    <h5 class="mt-3">Order Medicines</h5>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card service-card shadow p-3 text-center">
                    <img src="assets/img/ambulance.png" height="80" class="mx-auto" alt="Ambulance" />
                    <h5 class="mt-3">Emergency Help</h5>
                </div>
            </div>
        </div>
    </div>
</section>
