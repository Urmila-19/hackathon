<?php include 'header.php'; ?>

<section class="hero">
    <div class="container">
        <h1 class="display-4 fw-bold">Unified Digital Healthcare Platform</h1>
        <p class="lead mt-3">Book Appointments • Access Health Records • Order Medicines • Emergency Help</p>
        <a href="registrtion.php" class="btn btn-light btn-lg mt-3">Get Started</a>
    </div>
</section>

<?php include 'services.php'; ?>
<?php include 'footer.php'; ?>
