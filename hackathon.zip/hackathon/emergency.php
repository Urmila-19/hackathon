<?php
include 'db.php';
$msg = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $uid = $_SESSION['user_id'] ?? 0;
    mysqli_query($conn, "INSERT INTO emergency (user_id,message) VALUES ($uid,'Emergency Help Requested')");
    $msg = 'Emergency request sent';
}
include 'partials/header.php';
?>
<div class="container py-5 text-center">
    <div class="card shadow p-5">
        <h2 class="text-danger fw-bold">Emergency Assistance</h2>
        <p class="mt-3">Click the button below to request an ambulance immediately.</p>
        <?php if($msg) echo '<div class="alert alert-success">'.htmlspecialchars($msg).'</div>'; ?>
        <form method="POST"><button class="btn btn-danger btn-lg">Request Emergency Help</button></form>
    </div>
</div>
<?php include 'partials/footer.php'; ?>
