<?php
session_start();
include 'db.php';
$msg = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $uid = $_SESSION['user_id'] ?? 0;
    $doctor = mysqli_real_escape_string($conn, $_POST['doctor']);
    $date = $_POST['date'];
    $time = $_POST['time'];
    mysqli_query($conn, "INSERT INTO appointments (user_id,doctor,date,time) VALUES ($uid,'$doctor','$date','$time')");
    $msg = 'Appointment booked';
}
include 'partials/header.php';
?>
<div class="container py-5">
    <div class="card p-4 shadow">
        <h3 class="mb-3">Book an Appointment</h3>
        <?php if($msg) echo '<div class="alert alert-success">'.htmlspecialchars($msg).'</div>'; ?>
        <form method="POST">
            <select name="doctor" class="form-control mb-3" required>
                <option value="">Select Doctor</option>
                <option>General Physician</option>
                <option>Cardiologist</option>
                <option>Dermatologist</option>
            </select>
            <input type="date" name="date" class="form-control mb-3" required>
            <input type="time" name="time" class="form-control mb-3" required>
            <button class="btn btn-success w-100">Book Now</button>
        </form>
    </div>
</div>
<?php include 'partials/footer.php'; ?>
