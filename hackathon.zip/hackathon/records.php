<?php
session_start();
include 'db.php';
$uid = $_SESSION['user_id'] ?? 0;
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])){
    $target = 'uploads/'.basename($_FILES['file']['name']);
    move_uploaded_file($_FILES['file']['tmp_name'], $target);
    mysqli_query($conn, "INSERT INTO records (user_id,file_path) VALUES ($uid,'$target')");
}
include 'partials/header.php';
?>
<div class="container py-5">
    <h3 class="mb-4">My Medical Records</h3>
    <div class="card p-4 shadow">
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="file" class="form-control mb-3" required>
            <button class="btn btn-primary">Upload Record</button>
        </form>
        <hr>
        <h5>Uploaded Files</h5>
        <ul>
        <?php
        $res = mysqli_query($conn, "SELECT * FROM records WHERE user_id=$uid");
        while($r = mysqli_fetch_assoc($res)){
            echo '<li><a href="'.htmlspecialchars($r['file_path']).'" download>'.htmlspecialchars($r['file_path']).'</a></li>';
        }
        ?>
        </ul>
    </div>
</div>
<?php include 'partials/footer.php'; ?>
